#!/bin/bash

while true
do

cat ascii-art.txt
sleep 10

 timeout 10 termsaver urlfetcher -u https://www.pillowfort.social/Braeburned
 timeout 10 ffplay gandalf_crt.mp4
 timeout 10 curl parrot.live
 clear
 cat ./BH.txt
 sleep 5
 clear
 cat ./21.txt
 sleep 5

done
