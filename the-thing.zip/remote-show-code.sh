#!/bin/bash

termsaver programmer -p /home/pi/flashrom/* > /dev/tty1
